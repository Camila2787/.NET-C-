﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejerciciosClasePolimorfismo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vehiculo vehiculo1 = new Vehiculo("123DER", "CHEVROTLET", "2011");
            vehiculoTurismo vehiculo2 = new Vehiculo("322BSD", "MAZDA", "2102");
            Vehiculo vehiculo3
        }
    }
}
