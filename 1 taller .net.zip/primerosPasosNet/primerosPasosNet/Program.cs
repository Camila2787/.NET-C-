﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace primerosPasosNet
{
    internal class Program
    {
        static void Main(string[] args)

        {

            //Punto 2 taller practica


            //        decimal tasaCambioUSD = 0.00027m; 
            //        decimal tasaCambioEUR = 0.00023m; 


            //        Console.Write("Ingrese el salario:");
            //        decimal salarioIngresadoEnPesosCop = Convert.ToDecimal(Console.ReadLine());






            //        decimal salarioEnDolares = salarioIngresadoEnPesosCop * tasaCambioUSD;
            //        decimal salarioEnEuros = salarioIngresadoEnPesosCop * tasaCambioEUR;


            //        Console.WriteLine($"Salario en Pesos: {salarioIngresadoEnPesosCop:C}");
            //        Console.WriteLine($"Salario en Dólares: {salarioEnDolares:C}");
            //        Console.WriteLine($"Salario en Euros: {salarioEnEuros:C}");
            //        Console.WriteLine($"Fecha y Hora de la transacción: {DateTime.Now}");
            //    }
            //}


            //punto 3 practica

            // Solicitar las notas al usuario
            //double nota1, nota2, nota3;

            //aqui lo que se hace es verificar que el usuario no ingrese datos menores a 0 y mayores a 5
            //se utiliza un parse para convertir lo que ingrese el usuario a double
            //y en caso de que no se pueda convertir enviar una excepción
            //        Console.Write("Ingrese la primera nota (máximo 5): ");
            //        if (!double.TryParse(Console.ReadLine(), out nota1) || nota1 < 0 || nota1 > 5)
            //        {
            //            Console.WriteLine("Por favor, ingrese un valor válido para la nota (entre 0 y 5).");
            //            return;
            //        }

            //        Console.Write("Ingrese la segunda nota (máximo 5): ");
            //        if (!double.TryParse(Console.ReadLine(), out nota2) || nota2 < 0 || nota2 > 5)
            //        {
            //            Console.WriteLine("Por favor, ingrese un valor válido para la nota (entre 0 y 5).");
            //            return;
            //        }

            //        Console.Write("Ingrese la tercera nota (máximo 5): ");
            //        if (!double.TryParse(Console.ReadLine(), out nota3) || nota3 < 0 || nota3 > 5)
            //        {
            //            Console.WriteLine("Por favor, ingrese un valor válido para la nota (entre 0 y 5).");
            //            return;
            //        }

            //        // Calcular el promedio
            //        double promedio = (nota1 + nota2 + nota3) / 3;

            //        // Redondear el promedio a 2 decimales
            //        promedio = Math.Round(promedio, 2);

            //        // Imprimir el promedio
            //        Console.WriteLine($"Promedio: {promedio}");

            //        // Verificar si aprobó y mostrar mensaje en color
            //        if (promedio > 3.5)
            //        {
            //            Console.ForegroundColor = ConsoleColor.Green;
            //            Console.WriteLine("¡Aprobaste!");
            //            Console.ResetColor();
            //        }
            //        else
            //        {
            //            Console.ForegroundColor = ConsoleColor.Red;
            //            Console.WriteLine("No aprobaste.");
            //            Console.ResetColor();
            //        }
            //    }
            //}


            //punto 4 practica
            // Datos de la planta de producción
            //            int empleados = 5;
            //            int diasTrabajados = 6;
            //            int horasDiarias = 8;
            //            int produccionTotal = 1500;

            //            // Calcular indicadores, crear funciones
            //            CalcularProductividadPorHoraIndividual(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //            CalcularProductividadPorDiaIndividual(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //            CalcularProductividadGrupoPorDia(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //            CalcularVariacionAbsolutaHoraHombre(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //            CalcularVariacionRelativaHoraHombre(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //            CalcularVariacionRelativaProduccionGlobal(empleados, diasTrabajados, horasDiarias, produccionTotal);
            //        }

            //        //crear metodos utilizando las funciones para poder realizar la operacion e imprimirla
            //        static void CalcularProductividadPorHoraIndividual(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            double productividadPorHoraIndividual = produccionTotal / (empleados * diasTrabajados * horasDiarias);
            //            Console.WriteLine($"Productividad Individual por Hora: {productividadPorHoraIndividual} prendas/hora/empleado");
            //        }

            //        static void CalcularProductividadPorDiaIndividual(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            double productividadPorDiaIndividual = produccionTotal / (empleados * diasTrabajados);
            //            Console.WriteLine($"Productividad Individual por Día: {productividadPorDiaIndividual} prendas/día/empleado");
            //        }

            //        static void CalcularProductividadGrupoPorDia(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            double productividadGrupoPorDia = produccionTotal / diasTrabajados;
            //            Console.WriteLine($"Productividad del Grupo por Día: {productividadGrupoPorDia} prendas/día");
            //        }

            //        static void CalcularVariacionAbsolutaHoraHombre(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            double productividadInicial = produccionTotal / (empleados * diasTrabajados * horasDiarias);
            //            double productividadFinal = productividadInicial * 1.1; // Asumiendo un aumento del 10%

            //            double variacionAbsoluta = productividadFinal - productividadInicial;
            //            Console.WriteLine($"Variación Absoluta de la Productividad Hora Hombre: {variacionAbsoluta} prendas/hora/empleado");
            //        }

            //        static void CalcularVariacionRelativaHoraHombre(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            double productividadInicial = produccionTotal / (empleados * diasTrabajados * horasDiarias);
            //            double productividadFinal = productividadInicial * 1.1; // Asumiendo un aumento del 10%

            //            double variacionRelativa = (productividadFinal - productividadInicial) / productividadInicial * 100;
            //            Console.WriteLine($"Variación Relativa de la Productividad Hora Hombre: {variacionRelativa}%");
            //        }

            //        static void CalcularVariacionRelativaProduccionGlobal(int empleados, int diasTrabajados, int horasDiarias, int produccionTotal)
            //        {
            //            int produccionFinal = produccionTotal * 2; // Asumiendo un aumento del 100%

            //            double variacionRelativa = ((double)(produccionFinal - produccionTotal) / produccionTotal) * 100;
            //            Console.WriteLine($"Variación Relativa de la Producción Global: {variacionRelativa}%");
            //        }
            //    }
            //}

            //            Console.WriteLine("Colocar signo de pesos y separadores de mil:");
            //            double precioVenta = 100767.89;

            //            Console.WriteLine($"El precio de venta es: {precioVenta:C}"); //concatenar el precio de venta agregando el signo $
            //            Console.ReadKey(); //salto de linea
            //            Console.WriteLine("---------------------------");

            //        }
            //    }
            //}

            //Formatear porcentaje
            //reto individual


            //Console.WriteLine("Ingrese el nombre del empleado:");
            //string nombreEmpleado = Console.ReadLine();

            //Console.WriteLine("Ingrese el código del empleado:");
            //int codigoEmpleado = Convert.ToInt16(Console.ReadLine());

            //Console.WriteLine("Cantidad de horas laboradas:");
            //int horasLaboradas = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Ingrese el valor x hora: ");
            //double valorHora = Convert.ToDouble(Console.ReadLine());

            //double salarioSinFormato = horasLaboradas * valorHora;


            //Console.WriteLine("El salario es:" + salarioSinFormato);

            //double salarioRedondeado = Math.Round(salarioSinFormato, 2);

            //Console.WriteLine($"El salario redondeado a 2 decimales es: {salarioRedondeado:C}");

            //double salarioRedondeadoCercano = Math.Round(salarioSinFormato);
            //Console.WriteLine($"El salario redondeado al numero mas cercano es: {salarioRedondeadoCercano:C}");

            //if (salarioSinFormato >= 2600000)
            //{
            //    Console.WriteLine("Alerta: Este empleado no recibe subsidio de transporte.");
            //}




            //        }

            //    }
            //}

            //reto individual 2

            //            Console.Write("Ingresar su edad: ");
            //            int edad = Convert.ToInt32(Console.ReadLine());

            //            switch (edad)
            //            {
            //                case int n when (n >= 0 && n <= 5):
            //                    Console.WriteLine("Infante");
            //                    break;
            //                case int n when (n >= 6 && n <= 10):
            //                    Console.WriteLine("Niño");
            //                    break;
            //                case int n when (n >= 11 && n <= 15):
            //                    Console.WriteLine("Pre adolescente");
            //                    break;
            //               
            //        }
            //    }
            //}



            //RETO 0

            //            Console.WriteLine("Ingrese el nombre del empleado:");
            //            string nombreEmpleado = Console.ReadLine();

            //            Console.WriteLine("Ingrese el sueldo del empleado:");
            //            double sueldo = Convert.ToDouble(Console.ReadLine());

            //            Console.WriteLine("Ingrese el número de hijos del empleado:");
            //            int numeroHijos = Convert.ToInt32(Console.ReadLine());

            //            double bono = 0;

            //            switch (numeroHijos)
            //            {
            //                case 0:
            //                    if (sueldo <= 1160000)
            //                    {
            //                        bono = 0;
            //                    }
            //                    break;
            //                case int n when (n >= 1 && n <= 3):
            //                    if (sueldo >= 1160000 && sueldo <= 2320000)
            //                    {
            //                        bono = sueldo * 0.10;
            //                    }
            //                    break;
            //                case int n when (n > 3 && n <= 5):
            //                    if (sueldo <= 1160000)
            //                    {
            //                        bono = sueldo * 0.25;
            //                    }
            //                    break;
            //            }

            //            double total = sueldo + bono;

            //            Console.WriteLine($"El bono del empleado es: ${bono:N}");
            //            Console.WriteLine($"El total que el empleado recibirá es: ${total:N}");

            //            Console.WriteLine("\nPresione cualquier tecla para salir...");
            //            Console.ReadKey();
            //        }
            //    }
            //}


            //RETO 2
//            Console.WriteLine("Programa para determinar si un estudiante tiene derecho a recibir una beca");
//            Console.WriteLine("Fecha de simulación: " + DateTime.Now.ToShortDateString());

//            Console.WriteLine("Ingrese la distancia en kilómetros desde su casa hasta la universidad:");
//            double distancia = Convert.ToDouble(Console.ReadLine());

//            Console.WriteLine("Ingrese los ingresos familiares mensuales:");
//            double ingresosFamiliares = Convert.ToDouble(Console.ReadLine());

//            Console.WriteLine("Ingrese el estrato del estudiante:");
//            int estrato = Convert.ToInt32(Console.ReadLine());

//            if (distancia > 5 && ingresosFamiliares < 600000 && (estrato == 1 || estrato == 2))
//            {
//                double smlv = 908526; // Valor del Salario Mínimo Legal Vigente para el año 2022
//                double beca = smlv * 0.44;
//                Console.WriteLine("¡Felicitaciones! El estudiante cumple con los requisitos para recibir la beca.");
//                Console.WriteLine("Valor de la beca: $" + beca);
//            }
//            else
//            {
//                Console.WriteLine("El estudiante no cumple con los requisitos para recibir la beca.");
//            }
//        }
//    }
//}












